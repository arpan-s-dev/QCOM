# Medic Offline

An Android app for first aid, navigation, and communication that works with **zero network
connectivity** — built for the Qualcomm Snapdragon 8 Elite on-device AI hackathon.

Built by:
- **[Person 1 Name]** — [email] — on-device AI models (embedder, LLM, ASR)
- **[Person 2 Name]** — [email] — app architecture, medical corpus + safety logic, navigation, pitch

License: MIT (see `LICENSE`).

---

## What it does

Three sections, always reachable from the same screen, with a persistent status strip showing
exactly how confident the app is about your position:

- **TREAT** — describe an injury by voice or text. A deterministic safety-tree engine decides
  the severity (CRITICAL / SERIOUS / MODERATE / MINOR) — not the language model — and a
  retrieval-augmented prompt has the model explain and cite a small offline TCCC/MARCH-based
  first-aid corpus shipped in the app. Spoken back via on-device text-to-speech, with the
  disclaimer always shown on screen.
- **ORIENT** — when GPS is unavailable or detected as spoofed, falls back to dead reckoning,
  then to a **solar compass**: point the phone at the visible sun and the app derives a
  true-north heading from the sun's known position for the current time and rough location
  (NOAA/Meeus solar position algorithm).
- **COMMUNICATE** — a minimal medic↔casualty translation box, and an SOS card that drafts a
  short structured distress summary (injury / position / people affected / needs / severity)
  from the conversation so far.

The status strip itself is the app's signature element: a pulsing dot shows the current
position source (`GPS_TRUSTED` → `DEAD_RECKONING` → `SOLAR_FIX`), and a bright AIRPLANE MODE
badge is always visible. The app requests no `INTERNET` permission at all.

---

## ⚠️ Important: this is a hackathon prototype, not a medical device

- The first-aid guidance has **not** been clinically validated and is not a substitute for
  professional medical care or training. Every screen carries this disclaimer.
- See `STATUS.md` for a full, honest list of what's implemented, what's stubbed, and what's
  known to be incomplete or limited. We'd rather you read that than discover it live.

---

## Architecture

```mermaid
flowchart TD
    subgraph UI["UI layer (Compose)"]
        SS[StatusStrip<br/>signature element]
        SW[SectionSwitcher<br/>TREAT / ORIENT / COMMUNICATE]
        CS[ChatSurface]
        OS[OrientScreen<br/>+ AR compass overlay]
        CO[CommunicateScreen<br/>translation + SOS]
    end

    subgraph VM["MainViewModel"]
        STATE[AppUiState<br/>StateFlow]
    end

    subgraph CORE["Core logic (deterministic, tested)"]
        ST[SafetyTree<br/>+ NegationAwareMatcher<br/>+ BleedingClassifier]
        PSM[PositionStateMachine]
        SD[SpoofDetector]
        SC[SolarMath / SolarCompass<br/>NOAA-Meeus]
    end

    subgraph AI["AI layer (interface-based)"]
        IFACE[["AiService interface<br/>embed / generate / transcribe / translate"]]
        STUB[StubAiService<br/>canned responses, dev-time]
        REAL[("RealAiService<br/>Person 1, on-device models:<br/>Genie bundle LLM + BGE embedder + ASR")]
        ORCH[TriageOrchestrator]
        PROMPT[PromptTemplates<br/>grounded RAG prompt]
        VOICE[VoiceLoopManager<br/>mic + Android TTS]
    end

    subgraph DATA["Data"]
        CORPUS[("first_aid_corpus.json<br/>93 TCCC/MARCH chunks")]
        VEC[("corpus_vectors.bin<br/>BGE embeddings, shipped in APK")]
        RET[Retriever<br/>in-memory cosine top-k]
    end

    SS & SW & CS & OS & CO --> STATE
    STATE --> VM
    VM --> ST
    VM --> ORCH
    VM --> VOICE
    VM --> PSM
    PSM --> SD
    OS --> SC

    ORCH --> ST
    ORCH --> RET
    ORCH --> PROMPT
    ORCH --> IFACE
    IFACE -.->|dev time| STUB
    IFACE -.->|production swap, one line| REAL

    RET --> CORPUS
    RET --> VEC
    CORPUS --> VEC
```

**Key design decision:** every model-backed capability goes through the `AiService` interface.
`StubAiService` (canned text) lets the whole app — UI, safety tree, retrieval, voice loop — be
built, demoed, and tested before the real on-device models exist. Swapping to the real
implementation is a one-line change in `MainViewModel.kt`.

**Key safety decision:** the deterministic `SafetyTree` is authoritative over the language
model for severity. The LLM can elaborate and cite sources, but the headline severity and
directive shown to the user always come from rule-based logic, which can't be talked into
softening a critical judgment by conversational framing the way a language model could be.

---

## Project structure

```
app/src/main/java/com/medic/app/
  core/       SafetyTree.kt              -- deterministic triage, negation-aware
  data/       CorpusRetrieval.kt         -- corpus model + cosine retrieval
  ai/         AiService.kt               -- the interface Person 1 implements
              PromptTemplates.kt         -- grounded RAG / SOS / translation prompts
              TriageOrchestrator.kt      -- wires safety tree + retrieval + LLM
              VoiceLoopManager.kt        -- mic capture + Android TextToSpeech
  nav/        PositionState.kt           -- PositionSource state machine
              SpoofDetector.kt           -- GPS jump plausibility check
              SolarCompass.kt            -- NOAA/Meeus solar position + heading correction
              DeviceOrientationReader.kt -- SensorManager rotation-vector wrapper for "sight sun"
  ui/         MainViewModel.kt, MainActivity.kt
              theme/                     -- design tokens
              components/                -- StatusStrip, ChatSurface, SectionSwitcher
              screens/                   -- OrientScreen, CommunicateScreen
app/src/test/java/com/medic/app/         -- JUnit tests (safety tree, position state, spoof detector)
corpus/       first_aid_corpus.json/.jsonl  -- the TCCC/MARCH corpus, ready to embed
scripts/      build_corpus.py              -- generates the corpus
              verify_safety_tree.py        -- Python reference impl + test runner (16/16 pass)
              verify_solar_math.py         -- Python NOAA/Meeus reference + sanity checks (4/4 pass)
docs/         PITCH_OUTLINE.md             -- 10-slide pitch deck outline
DEMO.md       -- run-of-show for the live demo, including the spoof-trigger walkthrough
STATUS.md     -- live progress tracker + honest list of gaps
```

---

## Setup / build

1. Open the repo root in Android Studio (a recent stable release — Compose BOM
   `2024.09.00`, Kotlin `2.0.20`, AGP `8.6.0` are pinned in the Gradle files; let Android
   Studio's Upgrade Assistant bump these if it flags newer compatible versions).
2. Let Gradle sync. No API keys or network access are required to build — the app has no
   `INTERNET` permission and the AI layer runs on `StubAiService` until Person 1's real
   implementation is wired in.
3. Run `./gradlew test` to run the JUnit unit tests for the safety tree, position state
   machine, and spoof detector.
4. Run on a device or emulator (`minSdk 26`). Grant microphone and location permissions when
   prompted.

### Swapping in the real AI models

In `MainViewModel.kt`:
```kotlin
private val aiService: AiService = StubAiService()  // <-- change to RealAiService()
```
Everything else — UI, retrieval, prompt templates, voice loop — is already built against the
`AiService` interface and needs no other changes.

### Running the verification scripts (no Android toolchain needed)

```bash
python3 scripts/verify_safety_tree.py   # 16 negation/priority test cases
python3 scripts/verify_solar_math.py    # 4 solar-geometry sanity checks
python3 scripts/build_corpus.py         # regenerates corpus/first_aid_corpus.json
```

---

## Usage

- **TREAT:** type or tap the mic and describe an injury. Watch the severity tag and read the
  disclaimer under each answer.
- **ORIENT:** watch the status strip — if it shows `SOLAR_FIX`, switch to this tab, point the
  phone's top edge at the sun, and tap "SIGHT SUN."
- **COMMUNICATE:** type a message for the casualty/medic translation box, or tap "GENERATE SOS
  SUMMARY" to draft a structured distress summary from the conversation so far.

See `DEMO.md` for a full walkthrough including how to trigger the GPS spoof-detection demo with
a mock-location tool.
